import './Background.css'
import video1 from '../../assets/video1.mp4'
import image1 from '../../assets/image1.png'
import image2 from '../../assets/image2.png'
import image3 from '../../assets/image3.png'
import defaultImage from '../../assets/defaultimage.png' // Import default image

const Background = ({playStatus, heroCount}) => {
    if(playStatus){
        return(
            <video className='background fade-in' autoPlay loop muted>
                <source src={video1} type='video/mp4' />
            </video>
        )
    } else if(heroCount === 0){
        return <img src={image1} className='background fade-in' alt='Hero 1' />
    } else if(heroCount === 1){
        return <img src={image2} className='background fade-in' alt='Hero 2' />
    } else if(heroCount === 2){
        return <img src={image3} className='background fade-in' alt='Hero 3' />
    } else { // Default case
        return <img src={defaultImage} className='background' alt='Default Background' />
    }
}

export default Background;